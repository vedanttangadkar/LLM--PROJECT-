from __future__ import annotations

from langchain.chains import RetrievalQA
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI


QA_PROMPT = PromptTemplate(
    input_variables=["context", "question"],
    template=(
        "You are a helpful PDF question answering assistant.\n"
        "Use only the provided context to answer the question.\n"
        "If the answer is not present in the context, say that you do not know.\n\n"
        "Context:\n{context}\n\n"
        "Question:\n{question}\n\n"
        "Answer:"
    ),
)


def build_qa_chain(retriever) -> RetrievalQA:
    """Build the RetrievalQA chain with a deterministic GPT model."""
    llm = ChatOpenAI(
        model="gpt-3.5-turbo",
        temperature=0,
    )

    return RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": QA_PROMPT},
    )


def build_contextual_question(question: str, chat_history: list[dict], history_turns: int = 3) -> str:
    """
    Include recent chat history in the query so simple follow-up questions work better.

    The RetrievalQA chain still answers from retrieved PDF content only.
    """
    if not chat_history:
        return question

    recent_turns = chat_history[-history_turns:]
    conversation_lines = []

    for item in recent_turns:
        conversation_lines.append(f"User: {item['question']}")
        conversation_lines.append(f"Assistant: {item['answer']}")

    conversation_text = "\n".join(conversation_lines)
    return (
        "Conversation history:\n"
        f"{conversation_text}\n\n"
        f"Current user question:\n{question}"
    )


def format_source_documents(source_documents: list) -> list[dict]:
    """Prepare source chunks for display in the Streamlit UI."""
    formatted_sources: list[dict] = []
    seen_citations: set[tuple[str, int, int]] = set()

    for document in source_documents:
        source_name = document.metadata.get("source", "Unknown source")
        page = int(document.metadata.get("page", 0))
        chunk_number = int(document.metadata.get("chunk_number", 0))
        citation_key = (source_name, page, chunk_number)

        if citation_key in seen_citations:
            continue

        seen_citations.add(citation_key)
        preview = document.page_content.strip().replace("\n", " ")

        if len(preview) > 350:
            preview = preview[:350].rstrip() + "..."

        formatted_sources.append(
            {
                "citation": f"{source_name} | Page {page} | Chunk {chunk_number}",
                "content": preview,
            }
        )

    return formatted_sources


def ask_pdf_question(qa_chain: RetrievalQA, question: str, chat_history: list[dict]) -> dict:
    """Run a question against the RetrievalQA chain and return answer + citations."""
    if qa_chain is None:
        raise ValueError("The question answering chain is not ready yet.")

    contextual_question = build_contextual_question(question, chat_history)
    result = qa_chain.invoke({"query": contextual_question})

    return {
        "answer": result.get("result", "No answer was generated."),
        "sources": format_source_documents(result.get("source_documents", [])),
    }
