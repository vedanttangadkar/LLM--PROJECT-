from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter


COLLECTION_NAME = "askmypdf_ai_collection"
MANIFEST_FILE = "processed_files.json"
EMBEDDING_MODEL = "text-embedding-3-small"


def get_embeddings_model() -> OpenAIEmbeddings:
    """Create the embedding model used by ChromaDB."""
    return OpenAIEmbeddings(model=EMBEDDING_MODEL)


def get_text_splitter(
    chunk_size: int = 1200,
    chunk_overlap: int = 200,
) -> RecursiveCharacterTextSplitter:
    """Use overlapping chunks so retrieval keeps enough surrounding context."""
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],
    )


def chunk_documents(documents: list[Document]) -> list[Document]:
    """Split PDF pages into smaller semantic chunks."""
    splitter = get_text_splitter()
    chunks = splitter.split_documents(documents)

    for index, chunk in enumerate(chunks, start=1):
        chunk.metadata["global_chunk_number"] = index

    return chunks


def build_chunk_ids(chunks: list[Document]) -> list[str]:
    """Build stable chunk IDs so Chroma can store each chunk clearly."""
    counters: dict[tuple[str, int], int] = {}
    chunk_ids: list[str] = []

    for chunk in chunks:
        file_id = chunk.metadata.get("file_id", "unknown-file")
        page = int(chunk.metadata.get("page", 0))
        counter_key = (file_id, page)
        counters[counter_key] = counters.get(counter_key, 0) + 1
        chunk_number = counters[counter_key]

        chunk.metadata["chunk_number"] = chunk_number
        chunk_ids.append(f"{file_id}-page-{page}-chunk-{chunk_number}")

    return chunk_ids


def get_vectorstore(persist_directory: str | Path) -> Chroma:
    """Open the persisted Chroma collection."""
    return Chroma(
        collection_name=COLLECTION_NAME,
        persist_directory=str(persist_directory),
        embedding_function=get_embeddings_model(),
    )


def _manifest_path(database_dir: str | Path) -> Path:
    return Path(database_dir) / MANIFEST_FILE


def load_processed_registry(database_dir: str | Path) -> dict:
    """Read the registry of already processed PDFs."""
    manifest_path = _manifest_path(database_dir)

    if not manifest_path.exists():
        return {}

    try:
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def save_processed_registry(database_dir: str | Path, registry: dict) -> None:
    """Persist the registry of processed PDFs."""
    manifest_path = _manifest_path(database_dir)
    manifest_path.write_text(
        json.dumps(registry, indent=2),
        encoding="utf-8",
    )


def update_processed_registry(database_dir: str | Path, processed_files: list[dict]) -> None:
    """Add newly indexed files to the local manifest."""
    registry = load_processed_registry(database_dir)
    timestamp = datetime.utcnow().isoformat() + "Z"

    for file_info in processed_files:
        registry[file_info["file_hash"]] = {
            "original_name": file_info["original_name"],
            "saved_name": file_info["saved_name"],
            "saved_path": file_info["saved_path"],
            "size_bytes": file_info["size_bytes"],
            "page_count": file_info["page_count"],
            "processed_at": timestamp,
        }

    save_processed_registry(database_dir, registry)
