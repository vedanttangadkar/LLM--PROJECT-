# AskMyPDF-AI

AskMyPDF-AI is a beginner-friendly AI PDF Question Answering project built with Python, Streamlit, LangChain, OpenAI, and ChromaDB. It lets users upload one or more PDF files, convert them into searchable embeddings, and ask natural-language questions about the document content.

The project is designed to run locally inside VS Code using:

```bash
streamlit run app.py
```

## Project Overview

This application uses Retrieval-Augmented Generation (RAG) to answer questions from PDF documents. Instead of sending an entire PDF to the language model, the app:

1. Extracts text from uploaded PDF files
2. Splits the text into manageable chunks
3. Creates embeddings for each chunk
4. Stores those embeddings in ChromaDB
5. Retrieves only the most relevant chunks for a question
6. Sends the retrieved chunks to GPT-3.5-turbo for answer generation

This improves response quality, reduces hallucinations, and makes large PDFs searchable.

## Features

- Upload one or multiple PDF files
- Extract text from PDFs page by page
- Split text using `RecursiveCharacterTextSplitter`
- Generate embeddings with `OpenAIEmbeddings`
- Store vectors in ChromaDB
- Ask questions in natural language
- Retrieve relevant chunks with semantic search
- Generate answers with `RetrievalQA`
- Display source citations below every answer
- Maintain chat history using Streamlit session state
- Show loading spinners for processing and answering
- Prevent duplicate PDF processing using file hashing
- Use modular Python utility files
- Handle common errors gracefully

## Technologies Used

- Python
- Streamlit
- LangChain
- OpenAI API
- ChromaDB
- PyPDF
- python-dotenv

## Architecture Explanation

AskMyPDF-AI follows a simple RAG pipeline:

1. **Upload Layer**
   Users upload one or more PDF files from the Streamlit interface.

2. **Document Loading Layer**
   The app saves each file locally and extracts readable text using `pypdf`.

3. **Chunking Layer**
   Extracted text is split into overlapping chunks using `RecursiveCharacterTextSplitter`.

4. **Embedding Layer**
   Each chunk is converted into vector embeddings with `OpenAIEmbeddings`.

5. **Vector Database Layer**
   The vectors are stored locally in ChromaDB under the `database/` folder.

6. **Retrieval Layer**
   When a user asks a question, ChromaDB retrieves the most relevant chunks.

7. **Answer Generation Layer**
   `RetrievalQA` sends the retrieved chunks to `gpt-3.5-turbo` and returns the answer.

8. **Presentation Layer**
   Streamlit displays the answer, source citations, and the full session chat history.

## Folder Structure

```text
AskMyPDF-AI/
│
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
│
├── uploads/
│
├── database/
│
├── utils/
│   ├── pdf_loader.py
│   ├── embeddings.py
│   ├── retriever.py
│   └── chat_handler.py
│
└── assets/
    └── screenshot.png
```

## Installation Steps

### 1. Open the Project in VS Code

Open the `AskMyPDF-AI` folder in VS Code.

### 2. Create a Virtual Environment

Windows:

```bash
python -m venv .venv
```

Activate it:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install Requirements

```bash
pip install -r requirements.txt
```

### 4. Create the Environment File

Copy `.env.example` to `.env` and add your OpenAI API key:

```env
OPENAI_API_KEY=your_api_key_here
```

## How to Get an OpenAI API Key

1. Go to the OpenAI platform dashboard.
2. Sign in to your OpenAI account.
3. Create an API key from the API keys section.
4. Paste the key into your local `.env` file.

Important:
Do not commit your real API key to GitHub.

## How to Run the Project

From the project root:

```bash
streamlit run app.py
```

After the app opens in your browser:

1. Upload one or more PDF files
2. Click **Process PDFs**
3. Wait for embeddings to be created
4. Ask questions in the chat box
5. Review the cited source chunks under each answer

## Example Screenshots

The project includes a placeholder screenshot file here:

```text
assets/screenshot.png
```

You can replace it with a real screenshot after running the app locally.

Example Markdown image:

```markdown
![AskMyPDF-AI Screenshot](assets/screenshot.png)
```

## Engineering Challenge

**Challenge:**  
The system initially retrieved irrelevant chunks from PDFs which caused inaccurate answers and hallucinations.

**Solution:**  
Implemented better chunking strategy, semantic retrieval, reduced model temperature, and optimized chunk overlap.

## Future Improvements

- Add OCR support for scanned PDFs
- Add per-document delete or reset options
- Add support for DOCX and TXT files
- Add streaming responses
- Add conversation memory summarization
- Add user authentication and cloud storage
- Add metadata filters for document-specific Q&A

## Beginner Notes

- `uploads/` stores saved PDF files
- `database/` stores the persistent Chroma vector database
- `utils/` keeps the logic modular and easier to understand
- Chat history is stored in Streamlit session state, so it remains available during the current app session
- Duplicate files are skipped using SHA256 file hashes

## Final Notes

This project is simple enough for a student project, but it still uses production-style ideas such as modular code structure, persistent vector storage, duplicate detection, session state, and error handling. It is a strong starting point for building more advanced RAG applications.
